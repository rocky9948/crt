from django.contrib import admin
from .models import register,Contact
# Register your models here.
admin.site.register(register)
admin.site.register(Contact)